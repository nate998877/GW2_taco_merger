Emplacement alternative de l'icone de TacO
------------------------------------------
Pour changer l'emplacement de l'ic�ne du menu de TacO sous l'ic�ne des param�tres de Guild Wars 2.
Ce changement peut apporter les am�liorations suivantes :
- Donner plus d'espace pour les sous menu de GW2 TacO.
- Permettre de palier a un souci de taille de l'ic�ne qui (rarement) ne se conforme pas a celle du jeu.

Proc�dure :
- Remplacer les 4 fichiers .CSS du dossier de TacO par ceux de l'archive ici pr�sent.
- Red�marrer GW2 TacO pour que les changements soient pris en compte.



Alternate TacO Icon Location
----------------------------
To change the location of the TacO menu icon under the Guild Wars 2 settings icon.
This change may bring the following improvements:
- Give more space for the submenus of GW2 TacO.
- Allow leveling has a problem with the size of the icon which (rarely) does not conform to that of the game.

Procedure:
- Replace the 4 .CSS files from the TacO folder with those from the archive here.
- Restart GW2 TacO for the changes to be taken into account.



Alternative TacO-Symbolposition
-------------------------------
So �ndern Sie die Position des TacO-Men�symbols unter dem Guild Wars 2-Einstellungssymbol.
Diese �nderung kann die folgenden Verbesserungen bringen:
- Geben Sie mehr Platz f�r die Untermen�s von GW2 TacO.
- Beim Leveln zulassen ist ein Problem mit der Gr��e des Symbols aufgetreten, das (selten) nicht der des Spiels entspricht.

Verfahren:
- Ersetzen Sie die 4 .CSS-Dateien aus dem TacO-Ordner durch die aus dem Archiv hier.
- Starten Sie GW2 TacO neu, damit die �nderungen ber�cksichtigt werden.