Emplacement par d�faut de l'icone de TacO
-----------------------------------------
Pour remettre l'ic�ne du menu de TacO a droite des ic�nes de Guild Wars 2 (emplacement par d�faut) :

- Remplacer les 4 fichiers .CSS du dossier de TacO par ceux de l'archive ici pr�sent.
- Red�marrer TacO, le menu sera de nouveau a son emplacement d'origine, et adaptera sa taille selon l'API

NB: Il est possible qu'au premier lancement la taille ou l'emplacement ne soit pas ceux de la taille de votre interface
    C'est un des probl�mes qui avait pousser a changer la position de l'ic�ne, il faut alors ouvrir les r�glages du jeu
    et modifier la taille de l'interface choisi pour forcer un changement de taille puis remettre la taille que vous aviez
    a l'origine et cela obligera l'API � renvoyer l'information de la taille de l'interface � TacO.



Default location of the TacO icon
---------------------------------
To return the TacO menu icon to the right of the Guild Wars 2 icons (default location):

- Replace the 4 .CSS files from the TacO folder with those from the archive here.
- Restart TacO, the menu will be back to its original location, and will adapt its size according to the API

NB: It is possible that at the first launch the size or the location are not those of the size of your interface
    This is one of the problems that led to change the position of the icon, you have to open the game settings
    and modify the size of the interface chosen to force a size change then reset the size you had
    at the origin and this will force the API to return the interface size information to TacO.



Standardspeicherort des TacO-Symbols
------------------------------------
So kehren Sie das TacO-Men�symbol rechts neben den Guild Wars 2-Symbolen zur�ck (Standardspeicherort):

- Ersetzen Sie die 4 .CSS-Dateien aus dem TacO-Ordner durch die aus dem Archiv hier.
- Starten Sie TacO neu. Das Men� befindet sich wieder an seinem urspr�nglichen Speicherort und passt seine Gr��e entsprechend der API an

NB: Es ist m�glich, dass beim ersten Start die Gr��e oder der Speicherort nicht der Gr��e Ihrer Benutzeroberfl�che entspricht
    Dies ist eines der Probleme, die dazu gef�hrt haben, dass sich die Position des Symbols ge�ndert hat. Sie m�ssen die Spieleinstellungen �ffnen
    und �ndern Sie die Gr��e der Schnittstelle, die ausgew�hlt wurde, um eine Gr��en�nderung zu erzwingen, und setzen Sie dann die Gr��e zur�ck, die Sie hatten
    am Ursprung und dies zwingt die API, die Schnittstellengr��eninformationen an TacO zur�ckzugeben.